let player;
let fruits = [];
let trash = [];
let score = 0;
let timer = 30;
let gameOver = false;

function setup() {
  createCanvas(600, 400);
  player = new Player();
  for (let i = 0; i < 5; i++) {
    fruits.push(new Item("fruit"));
    trash.push(new Item("trash"));
  }
  setInterval(() => {
    if (!gameOver) {
      timer--;
      if (timer <= 0) {
        gameOver = true;
      }
    }
  }, 1000);
}

function draw() {
  background(100, 200, 100); // verde
  player.show();
  player.move();

  for (let f of fruits) {
    f.update();
    f.show();
    if (player.hits(f)) {
      score += 10;
      f.reset();
    }
  }

  for (let t of trash) {
    t.update();
    t.show();
    if (player.hits(t)) {
      score -= 5;
      t.reset();
    }
  }

  fill(255);
  textSize(18);
  text("Pontuação: " + score, 10, 20);
  text("Tempo: " + timer, 10, 40);

  if (gameOver) {
    background(0, 150);
    fill(255);
    textSize(32);
    textAlign(CENTER);
    text("Fim de Jogo!", width / 2, height / 2 - 20);
    text("Pontuação final: " + score, width / 2, height / 2 + 20);
    noLoop();
  }
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) {
    player.setDir(-1);
  } else if (keyCode === RIGHT_ARROW) {
    player.setDir(1);
  }
}

function keyReleased() {
  player.setDir(0);
}

class Player {
  constructor() {
    this.x = width / 2;
    this.y = height - 20;
    this.dir = 0;
  }

  show() {
    fill(255, 255, 0);
    rect(this.x, this.y, 40, 20);
  }

  setDir(d) {
    this.dir = d;
  }

  move() {
    this.x += this.dir * 5;
    this.x = constrain(this.x, 0, width - 40);
  }

  hits(item) {
    return (
      item.y > this.y &&
      item.y < this.y + 20 &&
      item.x > this.x &&
      item.x < this.x + 40
    );
  }
}

class Item {
  constructor(type) {
    this.type = type;
    this.reset();
  }

  reset() {
    this.x = random(width);
    this.y = random(-200, -50);
    this.speed = random(2, 5);
  }

  update() {
    this.y += this.speed;
    if (this.y > height) {
      this.reset();
    }
  }

  show() {
    if (this.type === "fruit") {
      fill(255, 0, 0);
      ellipse(this.x, this.y, 20, 20); // maçã
    } else {
      fill(100);
      rect(this.x, this.y, 15, 15); // lixo
    }
  }
}